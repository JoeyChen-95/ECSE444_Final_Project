/*
 * lab1math.h
 *
 *  Created on: 2022年9月14日
 *      Author: Mr.Chimpanzee
 */

#ifndef STM32L4XX_HAL_DRIVER_INC_LAB1MATH_H_
#define STM32L4XX_HAL_DRIVER_INC_LAB1MATH_H_





#endif /* STM32L4XX_HAL_DRIVER_INC_LAB1MATH_H_ */

#include "main.h"

void cMax(float *array, uint32_t size, float *max, uint32_t *maxIndex){
	(*max) = array[0];
	(*maxIndex) = 0;

	for(uint32_t i =1;i<size;i++){
		if(array[i]>(*max)){
			(*max)=array[i];
			(*maxIndex)=i;
		}
	}
}


extern void asmMax(float *array, uint32_t size, float *max, uint32_t *maxIndex);


void cMult(float *a, float *b, float *y, uint32_t size){
	for(uint32_t i=0;i<size;i++){
		y[i]=a[i]*b[i];
	}
}

void cStd(float *A, uint32_t size, float *std){
	float sum=0;
	float mean=0;
	(*std)=0;

	for(uint32_t i=0;i<size;i++){
		sum=sum+A[i];
	}
	mean=sum/size;

	float meanDiff=0;

	for(uint32_t i=0;i<size;i++){
		meanDiff=A[i]-mean;
		(*std)=*std+meanDiff*meanDiff;
	}

	(*std)=(*std)/(size-1);
	(*std)=sqrt(*std);
}
